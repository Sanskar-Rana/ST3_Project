package com.db;

import java.sql.Connection;

public class DBConnection {



	public static Connection getCon() {


		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");

		}
		catch(Exception e)
		{
			System.out.println("Exception " + e);
		}
		return null;

	}

}
