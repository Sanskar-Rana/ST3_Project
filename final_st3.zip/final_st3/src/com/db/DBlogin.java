package com.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class DBlogin {
	static String url="";
	static String user="";
	static String password="";
	Connection con=null;
	String sql = "select * from st3 where uname=? and password=? ";
	public boolean check(String username,String password)
	{

		url = "jdbc:oracle:thin:@localhost:1521:xe";
		user = "system";
		password = "apple123";
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection(url,user,password);
			PreparedStatement st = con.prepareStatement(sql);
			st.setString(1, username);
			st.setString(2, password);
			ResultSet rs = st.executeQuery();
			if(rs.next())
			{
				return true;
			}
			con.close();

		}
		catch(Exception e)
		{
			System.out.print("Exception ayo hai"+e);
		}
		return false;

	}
}