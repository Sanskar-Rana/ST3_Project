package com.db;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/DBregister")
public class DBregister extends HttpServlet {
	private static final long serialVersionUID = 1L;
	String name="";
	String email="";
	String gender="";
	String pass="";
	String uname="";
	String phone="";
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 PrintWriter out = response.getWriter();
		name = request.getParameter("name");
		email = request.getParameter("email");
		gender = request.getParameter("gender");
		phone = request.getParameter("phone");
		uname = request.getParameter("username");
		pass = request.getParameter("password");
		
		
		 try {
	
	            Class.forName("oracle.jdbc.driver.OracleDriver");
	            
	            //creating connection with the database 
	            Connection con = DriverManager.getConnection
	                        ("jdbc:oracle:thin:@localhost:1521:xe","system","apple123");

	            PreparedStatement ps = con.prepareStatement
	                        ("insert into st3 values(?,?,?,?,?,?)");

	            ps.setString(1, name);
	            ps.setString(2, email);
	            ps.setString(3, gender);
	            ps.setString(4, phone);
	            ps.setString(5, uname);
	            ps.setString(6, pass);
	            int i = ps.executeUpdate();
	            
	            if(i > 0) {
	                out.println("You are sucessfully registered");
	            }
	            con.close();
	            response.sendRedirect("welcome.jsp");
	        
	        }
	        catch(Exception se) {
	            se.printStackTrace();
	        }
		

	}
}
